Fractal Project

By; Max Bruggink
Instructions:
javac Canvas.java
java Canvas

Acceptable user inputs for fractals:
    For Rectangle: rectangle or Rectangle
    For Circle: Circle or circle
    For Triangle: Triangle or triangle

All fractals are written in the Canvas class and methods are called in them. All shape classes are in their own files.
