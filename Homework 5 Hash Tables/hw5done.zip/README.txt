Project 5 HashMaps:

Written by brugg123

javac HashMap.java

All testing was done using TextEntry.java from CSCI 1933 help

Creates a hashmap using hashing function & values are put into table using
"put" function
