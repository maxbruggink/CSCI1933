Project 2 Battleboats Game

Written by brugg123

Instructions to run:
javac Main.java
javac Battleboard.java

*Run: java Main to play game*

Commands:
  For running debug mode: debug or Debug
  For running normal mode: normal or Normal
  To shoot cannon: cannon or Cannon
  To use drone: drone or Drone
  To exit game: exit
